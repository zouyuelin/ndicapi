#ifdef __cplusplus
extern "C" {
#endif

#define FLATCC_VERSION_TEXT "0.6.0-pre"
#define FLATCC_VERSION_MAJOR 0
#define FLATCC_VERSION_MINOR 6
#define FLATCC_VERSION_PATCH 0
/* 1 or 0 */
#define FLATCC_VERSION_RELEASED 0

#ifdef __cplusplus
}
#endif
