#ifndef _GST_PLUGINS_BASE__STDINT_H
#define _GST_PLUGINS_BASE__STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "gst-plugins-base 1.16.1"
/* generated using gnu compiler gcc (Ubuntu 9.3.0-17ubuntu1~20.04) 9.3.0 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
